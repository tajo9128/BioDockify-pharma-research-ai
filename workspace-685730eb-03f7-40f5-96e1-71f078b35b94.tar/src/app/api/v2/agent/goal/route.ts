import { NextRequest, NextResponse } from 'next/server'
import { AgentZero } from '@/lib/agent-zero'
import { getToolRegistry } from '@/lib/tools/tool-registry'
import { getPersistentMemory } from '@/lib/memory'

export async function POST(request: NextRequest) {
  try {
    const { goal, stage } = await request.json()

    // Validate input
    if (!goal || typeof goal !== 'string') {
      return NextResponse.json({
        success: false,
        error: 'Goal is required and must be a string'
      }, { status: 400 })
    }

    if (!['early', 'middle', 'late'].includes(stage)) {
      return NextResponse.json({
        success: false,
        error: 'Stage must be one of: early, middle, late'
      }, { status: 400 })
    }

    // Initialize Agent Zero
    const memory = getPersistentMemory()
    const toolRegistry = getToolRegistry()
    const toolsMap = new Map()

    // Convert tool registry tools to Map
    const toolNames = toolRegistry.listTools()
    for (const name of toolNames) {
      const tool = toolRegistry.getTool(name)
      if (tool) {
        toolsMap.set(name, tool)
      }
    }

    const agent = new AgentZero(toolsMap, memory)

    // Generate task ID
    const taskId = crypto.randomUUID()

    // Execute goal asynchronously
    agent.executeGoal(goal, stage as 'early' | 'middle' | 'late').then(async (result) => {
      // Store result in memory
      await memory.store({
        taskId,
        goal,
        stage,
        result,
        timestamp: new Date(),
        type: 'goal'
      })

      // Update progress
      const completedTasks = result.tasks.filter(t => t.status === 'completed').length
      const totalTasks = result.tasks.length
      await memory.updateProgress(stage, completedTasks, totalTasks)
    }).catch(async (error) => {
      // Store error
      await memory.store({
        taskId,
        goal,
        stage,
        error: error.message,
        timestamp: new Date(),
        type: 'goal'
      })
    })

    return NextResponse.json({
      success: true,
      taskId,
      message: 'Agent Zero started',
      stage
    })

  } catch (error: any) {
    return NextResponse.json({
      success: false,
      error: error.message || 'Internal server error'
    }, { status: 500 })
  }
}
