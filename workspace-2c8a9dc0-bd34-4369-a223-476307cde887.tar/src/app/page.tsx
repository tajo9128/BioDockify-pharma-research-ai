'use client'

import { useState, useEffect } from 'react'
import { Sparkles, TrendingUp, Lightbulb, FileText, FileOutput, Search, Activity, Settings, Database, Zap, ChevronRight, Play, Download, RefreshCw, CheckCircle, XCircle, Clock } from 'lucide-react'

// Types
type ConsoleLog = {
  id: string
  message: string
  type: 'info' | 'success' | 'warning' | 'error'
  timestamp: Date
}

type AgentThinking = {
  type: string
  description: string
  tool?: string
}

type ResearchResults = {
  themes?: Array<{
    keywords: string[]
    paperCount: number
  }>
  gaps?: Array<{
    description: string
    type: string
    novelty: number
  }>
}

type View = 'home' | 'research' | 'results' | 'lab' | 'settings'

export default function BioDockify() {
  // State
  const [activeView, setActiveView] = useState<View>('home')
  const [researchTopic, setResearchTopic] = useState('')
  const [consoleLogs, setConsoleLogs] = useState<ConsoleLog[]>([])
  const [currentTaskId, setCurrentTaskId] = useState<string | null>(null)
  const [agentZeroMode, setAgentZeroMode] = useState(false)
  const [agentThinking, setAgentThinking] = useState<AgentThinking[]>([])
  const [researchResults, setResearchResults] = useState<ResearchResults>({})
  const [recentResearch, setRecentResearch] = useState<Array<{ id: string; topic: string; date: string }>>([])

  // Helper functions
  const addConsoleLog = (message: string, type: ConsoleLog['type'] = 'info') => {
    const newLog: ConsoleLog = {
      id: Date.now().toString() + Math.random(),
      message,
      type,
      timestamp: new Date()
    }
    setConsoleLogs(prev => [...prev, newLog])
  }

  const startAgentZeroMode = () => {
    setAgentZeroMode(true)
    addConsoleLog('Agent Zero mode activated', 'success')

    // Start streaming Agent Zero thinking
    const eventSource = new EventSource(`http://localhost:8000/api/v2/agent/thinking?taskId=${currentTaskId}`)

    eventSource.onmessage = (event) => {
      const step = JSON.parse(event.data)
      setAgentThinking(prev => [...prev, step])
    }

    eventSource.onerror = () => {
      eventSource.close()
      setAgentZeroMode(false)
    }
  }

  const generateLatexReport = async () => {
    if (!currentTaskId) return
    try {
      const response = await fetch('http://localhost:8000/api/v2/export/latex', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskId: currentTaskId })
      })

      const blob = await response.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `research_${currentTaskId}.tex`
      a.click()

      addConsoleLog('LaTeX thesis generated', 'success')
      loadRecentExports()
    } catch (error) {
      addConsoleLog('Failed to generate LaTeX', 'error')
    }
  }

  const startResearch = async () => {
    if (!researchTopic.trim()) return

    const taskId = Date.now().toString()
    setCurrentTaskId(taskId)

    addConsoleLog(`Starting research on: ${researchTopic}`, 'info')
    addConsoleLog(`Task ID: ${taskId}`, 'info')

    setActiveView('research')

    // Simulate research process
    setTimeout(() => addConsoleLog('Fetching relevant papers...', 'info'), 1000)
    setTimeout(() => addConsoleLog('Analyzing entities...', 'info'), 2000)
    setTimeout(() => addConsoleLog('Extracting relationships...', 'info'), 3000)
    setTimeout(() => {
      addConsoleLog('Research complete!', 'success')
      setActiveView('results')

      // Set mock results
      setResearchResults({
        themes: [
          { keywords: ['drug discovery', 'protein targets', 'molecular binding'], paperCount: 45 },
          { keywords: ['clinical trials', 'efficacy', 'safety'], paperCount: 32 },
          { keywords: ['biomarkers', 'diagnosis', 'prognosis'], paperCount: 28 },
          { keywords: ['drug resistance', 'mutations', 'therapy'], paperCount: 24 },
          { keywords: ['pathways', 'signaling', 'regulation'], paperCount: 19 },
          { keywords: ['pharmacokinetics', 'metabolism', 'distribution'], paperCount: 15 }
        ],
        gaps: [
          { description: 'Limited studies on pediatric populations', type: 'Population gap', novelty: 0.85 },
          { description: 'Lack of combination therapy research', type: 'Therapeutic gap', novelty: 0.72 },
          { description: 'Insufficient long-term safety data', type: 'Clinical gap', novelty: 0.68 },
          { description: 'Underexplored biomarker applications', type: 'Diagnostic gap', novelty: 0.61 },
          { description: 'Missing mechanistic studies', type: 'Mechanistic gap', novelty: 0.54 }
        ]
      })

      setRecentResearch(prev => [
        { id: taskId, topic: researchTopic, date: new Date().toISOString() },
        ...prev.slice(0, 4)
      ])
    }, 4000)
  }

  const generateReport = async () => {
    if (!currentTaskId) return
    addConsoleLog('Generating DOCX report...', 'info')
    setTimeout(() => addConsoleLog('DOCX report generated successfully', 'success'), 2000)
  }

  const loadRecentExports = () => {
    // Mock function to load recent exports
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Navigation */}
      <nav className="border-b border-white/10 bg-slate-900/50 backdrop-blur-lg">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold">BioDockify</span>
            </div>

            <div className="flex items-center gap-2">
              {(['home', 'research', 'results', 'lab', 'settings'] as View[]).map((view) => (
                <button
                  key={view}
                  onClick={() => setActiveView(view)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    activeView === view
                      ? 'bg-white/10 text-white border border-white/20'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {view.charAt(0).toUpperCase() + view.slice(1)}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        {/* HOME VIEW */}
        {activeView === 'home' && (
          <div className="space-y-8">
            {/* Hero Section */}
            <div className="text-center py-12">
              <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
                BioDockify Research Platform
              </h1>
              <p className="text-xl text-gray-400 max-w-2xl mx-auto">
                Advanced bio-medical research powered by AI. Discover insights, analyze entities, and generate comprehensive reports.
              </p>
            </div>

            {/* Research Input */}
            <div className="max-w-3xl mx-auto">
              <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
                <label className="block text-sm font-medium mb-3 text-gray-300">
                  Enter Your Research Topic
                </label>
                <div className="flex gap-3">
                  <input
                    type="text"
                    value={researchTopic}
                    onChange={(e) => setResearchTopic(e.target.value)}
                    placeholder="e.g., Drug discovery for Alzheimer's disease targeting amyloid-beta proteins"
                    className="flex-1 px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white placeholder-gray-500"
                  />
                  <button
                    onClick={startResearch}
                    className="px-6 py-3 bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-xl font-semibold hover:opacity-90 transition-opacity flex items-center gap-2"
                  >
                    <Search className="w-5 h-5" />
                    Research
                  </button>
                </div>
              </div>
            </div>

            {/* Feature Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                { icon: Activity, title: 'Entity Extraction', desc: 'Identify drugs, diseases, proteins automatically' },
                { icon: Database, title: 'Knowledge Graph', desc: 'Explore relationships between entities' },
                { icon: FileText, title: 'Smart Reports', desc: 'Generate detailed research summaries' }
              ].map((feature, i) => (
                <div key={i} className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-colors">
                  <feature.icon className="w-8 h-8 text-emerald-400 mb-4" />
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-400">{feature.desc}</p>
                </div>
              ))}
            </div>

            {/* Recent Research */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <h2 className="text-xl font-bold mb-4">Recent Research</h2>
              {recentResearch.length > 0 ? (
                <div className="space-y-3">
                  {recentResearch.map((research) => (
                    <div
                      key={research.id}
                      className="flex items-center justify-between p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
                      onClick={() => {
                        setCurrentTaskId(research.id)
                        setResearchTopic(research.topic)
                        setActiveView('results')
                      }}
                    >
                      <div>
                        <div className="font-medium text-white">{research.topic}</div>
                        <div className="text-sm text-gray-500">{new Date(research.date).toLocaleDateString()}</div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-gray-500" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  No recent research. Start a new research project above.
                </div>
              )}
            </div>

            {/* NEW: Agent Zero Quick Access */}
            <div className="bg-white/5 border border-emerald-500/20 rounded-2xl p-8 mt-10">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500/20 to-emerald-500/5 flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">Agent Zero Assistant</h3>
                  <p className="text-sm text-gray-400">AI-powered autonomous research planning</p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button
                  onClick={() => {
                    setActiveView('research')
                    startAgentZeroMode()
                  }}
                  className="px-6 py-4 bg-gradient-to-r from-emerald-500/10 to-emerald-500/5 border border-emerald-500/20 rounded-xl hover:bg-emerald-500/20 transition-all text-left"
                >
                  <div className="text-white font-semibold mb-1">Autonomous Research</div>
                  <div className="text-sm text-gray-400">Let Agent Zero plan and execute</div>
                </button>

                <button className="px-6 py-4 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all text-left">
                  <div className="text-white font-semibold mb-1">Gap Analysis</div>
                  <div className="text-sm text-gray-400">Find research opportunities</div>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* RESEARCH VIEW */}
        {activeView === 'research' && (
          <div className="space-y-6">
            {/* Progress Header */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold">Research Progress</h2>
                {agentZeroMode && (
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-emerald-400 rounded-full animate-pulse"></div>
                    <span className="text-emerald-400 font-medium">Agent Zero Active</span>
                  </div>
                )}
              </div>

              {/* Progress Steps */}
              <div className="flex items-center justify-between mb-4">
                {[
                  { label: 'Search', status: 'complete' },
                  { label: 'Extract', status: 'complete' },
                  { label: 'Analyze', status: 'complete' },
                  { label: 'Complete', status: 'pending' }
                ].map((step, i) => (
                  <div key={i} className="flex items-center flex-1">
                    <div className="flex flex-col items-center flex-1">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${
                        step.status === 'complete' ? 'bg-emerald-500' :
                        step.status === 'active' ? 'bg-cyan-500 animate-pulse' :
                        'bg-gray-700'
                      }`}>
                        {step.status === 'complete' ? <CheckCircle className="w-5 h-5" /> : <Clock className="w-5 h-5" />}
                      </div>
                      <span className="text-sm text-gray-400">{step.label}</span>
                    </div>
                    {i < 3 && (
                      <div className="flex-1 h-1 bg-gray-700 mx-2">
                        <div className={`h-full ${step.status === 'complete' ? 'bg-emerald-500' : 'bg-gray-600'}`} style={{ width: '100%' }}></div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* NEW: Agent Zero Thinking (if in agent mode) */}
            {agentZeroMode && (
              <div className="bg-white/5 border border-emerald-500/20 rounded-2xl p-6 mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-3 h-3 bg-emerald-400 rounded-full animate-pulse"></div>
                  <h3 className="text-xl font-bold text-white">Agent Zero Thinking</h3>
                </div>

                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {agentThinking.length > 0 ? (
                    agentThinking.map((step, i) => (
                      <div key={i} className="border-l-2 border-emerald-500/50 pl-4 py-2">
                        <div className="text-sm text-emerald-400 font-mono">{step.type}</div>
                        <div className="text-gray-300">{step.description}</div>
                        {step.tool && (
                          <div className="text-xs text-gray-500 mt-1">
                            Tool: <span className="text-cyan-400">{step.tool}</span>
                          </div>
                        )}
                      </div>
                    ))
                  ) : (
                    <div className="text-gray-500 text-center py-4">
                      Agent Zero is analyzing the research topic...
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Console */}
            <div className="bg-black/30 border border-white/10 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold">Console Output</h3>
                <button
                  onClick={() => setConsoleLogs([])}
                  className="text-sm text-gray-400 hover:text-white transition-colors"
                >
                  Clear
                </button>
              </div>

              <div className="space-y-2 max-h-96 overflow-y-auto font-mono text-sm">
                {consoleLogs.length > 0 ? (
                  consoleLogs.map((log) => (
                    <div key={log.id} className="flex gap-3">
                      <span className="text-gray-500 shrink-0">{log.timestamp.toLocaleTimeString()}</span>
                      <span className={
                        log.type === 'success' ? 'text-emerald-400' :
                        log.type === 'error' ? 'text-red-400' :
                        log.type === 'warning' ? 'text-amber-400' :
                        'text-cyan-400'
                      }>
                        [{log.type.toUpperCase()}]
                      </span>
                      <span className="text-gray-300">{log.message}</span>
                    </div>
                  ))
                ) : (
                  <div className="text-gray-500 text-center py-8">
                    No logs yet. Start a research to see progress here.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* RESULTS VIEW */}
        {activeView === 'results' && (
          <div className="space-y-8">
            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                { label: 'Total Papers', value: '142', color: 'emerald' },
                { label: 'Drugs Identified', value: '28', color: 'cyan' },
                { label: 'Diseases Found', value: '15', color: 'purple' },
                { label: 'Proteins Linked', value: '52', color: 'amber' }
              ].map((stat, i) => (
                <div key={i} className="bg-white/5 border border-white/10 rounded-2xl p-6">
                  <div className="text-3xl font-bold mb-2 text-white">{stat.value}</div>
                  <div className="text-gray-400">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Entities Section */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <h2 className="text-2xl font-bold mb-6">Identified Entities</h2>
              <div className="space-y-6">
                {/* Drugs */}
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-emerald-400">Drugs (28)</h3>
                  <div className="flex flex-wrap gap-2">
                    {['Memantine', 'Donepezil', 'Rivastigmine', 'Galantamine', 'Lecanemab', 'Aducanumab', 'Donanemab', 'Pimavanserin', 'Suvorexant', 'Tasimelteon'].map((drug, i) => (
                      <span key={i} className="px-3 py-1 bg-emerald-500/10 text-emerald-300 rounded-full text-sm border border-emerald-500/20">
                        {drug}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Diseases */}
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-cyan-400">Diseases (15)</h3>
                  <div className="flex flex-wrap gap-2">
                    {['Alzheimer\'s Disease', 'Dementia', 'Cognitive Decline', 'Mild Cognitive Impairment', 'Neurodegeneration', 'Memory Loss', 'Aphasia', 'Agnosia'].map((disease, i) => (
                      <span key={i} className="px-3 py-1 bg-cyan-500/10 text-cyan-300 rounded-full text-sm border border-cyan-500/20">
                        {disease}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Proteins */}
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-purple-400">Proteins (52)</h3>
                  <div className="flex flex-wrap gap-2">
                    {['Amyloid-beta', 'Tau protein', 'APP', 'PSEN1', 'PSEN2', 'APOE4', 'BACE1', 'GSK3β', 'CDK5', 'NMDA Receptor'].map((protein, i) => (
                      <span key={i} className="px-3 py-1 bg-purple-500/10 text-purple-300 rounded-full text-sm border border-purple-500/20">
                        {protein}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Research Summary */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <h2 className="text-2xl font-bold mb-4">Research Summary</h2>
              <p className="text-gray-300 leading-relaxed">
                This research analyzed 142 papers focusing on drug discovery approaches for Alzheimer's disease targeting amyloid-beta proteins. Key findings indicate that monoclonal antibodies such as Lecanemab and Donanemab show promising results in reducing amyloid plaques and slowing cognitive decline. However, challenges remain regarding long-term efficacy, safety concerns including ARIA, and limited applicability across different disease stages. The research highlights significant opportunities in combination therapies, personalized treatment approaches, and early intervention strategies.
              </p>
            </div>

            {/* NEW: BERTopic Themes */}
            {researchResults.themes && (
              <div className="bg-white/5 border border-purple-500/20 rounded-2xl p-8 mb-10">
                <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                  <TrendingUp className="w-6 h-6 text-purple-400" />
                  Discovered Themes
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  {researchResults.themes.slice(0, 6).map((theme, i) => (
                    <div key={i} className="p-4 bg-purple-500/5 border border-purple-500/20 rounded-xl">
                      <div className="text-white font-semibold mb-2">Theme {i + 1}</div>
                      <div className="flex flex-wrap gap-2">
                        {theme.keywords.slice(0, 5).map((kw, j) => (
                          <span key={j} className="text-xs px-2 py-1 bg-purple-500/10 text-purple-300 rounded-full">
                            {kw}
                          </span>
                        ))}
                      </div>
                      <div className="text-xs text-gray-500 mt-2">{theme.paperCount} papers</div>
                    </div>
                  ))}
                </div>

                <button className="text-sm text-purple-400 hover:text-purple-300 transition-colors">
                  View Interactive Visualization →
                </button>
              </div>
            )}

            {/* NEW: Research Gaps */}
            {researchResults.gaps && (
              <div className="bg-white/5 border border-amber-500/20 rounded-2xl p-8 mb-10">
                <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                  <Lightbulb className="w-6 h-6 text-amber-400" />
                  Research Gaps & Opportunities
                </h3>

                <div className="space-y-3">
                  {researchResults.gaps.slice(0, 5).map((gap, i) => (
                    <div key={i} className="p-4 bg-amber-500/5 border border-amber-500/20 rounded-xl">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="text-white font-medium mb-1">{gap.description}</div>
                          <div className="text-sm text-gray-400">{gap.type}</div>
                        </div>
                        <div className="px-3 py-1 bg-amber-500/10 text-amber-400 rounded-full text-sm font-bold">
                          {(gap.novelty * 100).toFixed(0)}% novel
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* LAB VIEW */}
        {activeView === 'lab' && (
          <div className="space-y-8">
            {/* Protocol Generator */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <h2 className="text-2xl font-bold mb-6">Report Generator</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                {/* DOCX Export */}
                <button
                  onClick={generateReport}
                  disabled={!currentTaskId}
                  className={`w-full py-4 rounded-2xl font-semibold text-lg flex items-center justify-center gap-3 transition-all ${
                    currentTaskId
                      ? 'bg-gradient-to-r from-emerald-500 to-cyan-500 hover:opacity-90 text-white'
                      : 'bg-gray-800/50 text-gray-500 cursor-not-allowed border border-white/10'
                  }`}
                >
                  <FileText className="w-5 h-5" />
                  <span>Generate DOCX</span>
                </button>

                {/* NEW: LaTeX Export */}
                <button
                  onClick={generateLatexReport}
                  disabled={!currentTaskId}
                  className={`w-full py-4 rounded-2xl font-semibold text-lg flex items-center justify-center gap-3 transition-all ${
                    currentTaskId
                      ? 'bg-white/5 hover:bg-white/10 border border-white/10 text-white'
                      : 'bg-gray-800/50 text-gray-500 cursor-not-allowed border border-white/10'
                  }`}
                >
                  <FileOutput className="w-5 h-5" />
                  <span>Generate LaTeX</span>
                </button>
              </div>

              {!currentTaskId && (
                <div className="text-center py-8 text-gray-500">
                  Complete a research to enable report generation
                </div>
              )}
            </div>

            {/* Export History */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <h2 className="text-2xl font-bold mb-4">Export History</h2>
              <div className="text-center py-8 text-gray-500">
                No exports yet. Generate reports to see them here.
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                { icon: Download, title: 'Download All', desc: 'Export all research data' },
                { icon: RefreshCw, title: 'Refresh Results', desc: 'Re-run analysis' },
                { icon: FileText, title: 'Citation Export', desc: 'Generate bibliography' }
              ].map((action, i) => (
                <button key={i} className="p-6 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-colors text-left">
                  <action.icon className="w-6 h-6 text-emerald-400 mb-3" />
                  <h3 className="text-lg font-semibold mb-1">{action.title}</h3>
                  <p className="text-sm text-gray-400">{action.desc}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* SETTINGS VIEW */}
        {activeView === 'settings' && (
          <div className="space-y-8">
            {/* LLM Settings */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <h2 className="text-2xl font-bold mb-6">LLM Configuration</h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-300">API Key</label>
                  <input
                    type="password"
                    placeholder="Enter your LLM API key"
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white placeholder-gray-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-300">Model</label>
                  <select className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white">
                    <option value="gpt-4">GPT-4</option>
                    <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
                    <option value="claude-3">Claude 3</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-300">Temperature</label>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    defaultValue="0.7"
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-gray-500 mt-1">
                    <span>Precise</span>
                    <span>Creative</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Database Settings */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <h2 className="text-2xl font-bold mb-6">Database Configuration</h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-300">Database Type</label>
                  <select className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white">
                    <option value="sqlite">SQLite (Local)</option>
                    <option value="postgresql">PostgreSQL</option>
                    <option value="mysql">MySQL</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-300">Connection String</label>
                  <input
                    type="text"
                    placeholder="Enter database connection string"
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white placeholder-gray-500"
                  />
                </div>
              </div>
            </div>

            {/* API Settings */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <h2 className="text-2xl font-bold mb-6">API Configuration</h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-300">API Endpoint</label>
                  <input
                    type="text"
                    value="http://localhost:8000"
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-300">Rate Limit (requests/min)</label>
                  <input
                    type="number"
                    defaultValue="60"
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white"
                  />
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-white/10">
                <button className="px-6 py-3 bg-emerald-500 rounded-xl font-semibold hover:bg-emerald-600 transition-colors">
                  Save Configuration
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 bg-slate-900/50 mt-auto">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center justify-between text-gray-400">
            <div>© 2024 BioDockify. All rights reserved.</div>
            <div className="flex items-center gap-4">
              <a href="#" className="hover:text-white transition-colors">Documentation</a>
              <a href="#" className="hover:text-white transition-colors">Support</a>
              <a href="#" className="hover:text-white transition-colors">API</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
