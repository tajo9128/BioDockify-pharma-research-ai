// API service module for BioDockify pharmaceutical research platform
// All API calls are relative - the gateway handles routing

const API_BASE = '/api/v1';

export interface ResearchStatus {
  taskId: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  progress: number;
  currentStep: number;
  logs: string[];
  phase: string;
}

export interface ResearchResults {
  taskId: string;
  title: string;
  stats: {
    papers: number;
    entities: number;
    nodes: number;
    connections: number;
  };
  entities: {
    drugs: string[];
    diseases: string[];
    proteins: string[];
  };
  summary: string;
}

export interface ProtocolRequest {
  taskId: string;
  type: 'liquid-handler' | 'crystallization' | 'assay';
}

export interface ReportRequest {
  taskId: string;
  template: 'full' | 'summary' | 'executive';
}

export interface Settings {
  llm: {
    provider: 'openai' | 'ollama';
    apiKey?: string;
    ollamaUrl?: string;
  };
  database: {
    host: string;
    user: string;
    password: string;
  };
  elsevier?: {
    apiKey?: string;
  };
}

export interface ConnectionTest {
  type: 'llm' | 'database' | 'elsevier';
  status: 'success' | 'error';
  message: string;
}

// Helper function for API calls
async function apiRequest<T>(
  endpoint: string,
  options?: RequestInit
): Promise<T> {
  const url = `${API_BASE}${endpoint}`;

  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Unknown error' }));
    throw new Error(error.message || 'API request failed');
  }

  return response.json();
}

export const api = {
  // Research endpoints
  startResearch: (topic: string) =>
    apiRequest<{ taskId: string }>('/research/start', {
      method: 'POST',
      body: JSON.stringify({ topic }),
    }),

  getStatus: (taskId: string) =>
    apiRequest<ResearchStatus>(`/research/${taskId}/status`),

  getResults: (taskId: string) =>
    apiRequest<ResearchResults>(`/research/${taskId}/results`),

  cancelResearch: (taskId: string) =>
    apiRequest<{ success: boolean }>(`/research/${taskId}/cancel`, {
      method: 'POST',
    }),

  // Lab interface endpoints
  generateProtocol: (request: ProtocolRequest) =>
    apiRequest<{ url: string; filename: string }>('/lab/protocol', {
      method: 'POST',
      body: JSON.stringify(request),
    }),

  generateReport: (request: ReportRequest) =>
    apiRequest<{ url: string; filename: string }>('/lab/report', {
      method: 'POST',
      body: JSON.stringify(request),
    }),

  getRecentExports: () =>
    apiRequest<{ id: string; type: string; filename: string; createdAt: string }[]>('/lab/exports'),

  // Settings endpoints
  testConnection: (type: 'llm' | 'database' | 'elsevier') =>
    apiRequest<ConnectionTest>(`/settings/test/${type}`),

  getSettings: () =>
    apiRequest<Settings>('/settings'),

  saveSettings: (settings: Settings) =>
    apiRequest<{ success: boolean }>('/settings', {
      method: 'POST',
      body: JSON.stringify(settings),
    }),

  // History endpoints
  getResearchHistory: () =>
    apiRequest<{ id: string; topic: string; status: string; createdAt: string }[]>('/research/history'),
};

export default api;
